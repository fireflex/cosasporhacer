<!doctype html>
<html>
<head>
    <title>Cosasparahacer | </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/overhang.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/general.css')); ?>" rel="stylesheet">
</head>
<body>
       <header>
       </header>
    <div class="container">
           <div id="main" class="row">
                       <?php echo $__env->yieldContent('content'); ?>
           </div>
    </div>
       <footer class="row">
               <div id="copyright">Jaime P. Bravo</div>
       </footer>
    <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('/js/parsley.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('/js/overhang.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('/js/general.js')); ?>"></script>   
</body>
</html>
