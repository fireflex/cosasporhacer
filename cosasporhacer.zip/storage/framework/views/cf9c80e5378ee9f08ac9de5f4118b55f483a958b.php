<?php $__env->startSection('content'); ?>
<div class="row">
  <h3 class="text-center" style="margin-top: 0;">Mi lista de tareas</h3>
</div>
<div class="row" style="margin-bottom:30px;">
  <div class="col-md-4 col-lg-4 col-md-offset-8">
    <input type="text" name="filtro" placeholder="Buscar una tarea" id="filtro" class="form-control">
  </div>
</div>
    <div class="jumbotron">
<div class="row" style="margin-bottom: 20px;"> 
  <div class="col-md-10 col-lg-10 col-md-offset-2">
    <form  method="post" accept-charset="utf-8" id="crear-tarea" class="form-inline">
      <input type="text" name="tarea" class="form-control" placeholder="Agregar nueva tarea"  style="width: 500px;" required>
      <select name="categoria" id="categoria" class="form-control" required>
        <option value="">Selecciona una categoria</option>
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
      <input type="submit" name="agregar" value="Agregar" class="btn btn-primary">
    </form>
  </div>
  </div>
<div class="row"> 
  <div class="col-md-10 col-lg-11 col-md-offset-3">
    <ul id="lista-tareas">
       <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <li <?php if($tarea->realizada): ?> == 1) style="text-decoration:line-through;" <?php endif; ?>>
          <input type="checkbox" name="tarea" value="<?php echo e($tarea->id); ?>" class="marcar-tarea" title="Marcar como realizado" <?php if($tarea->realizada): ?> == 1) checked <?php endif; ?>>
          <?php echo e($tarea->tarea); ?> <span class="badge" style="background:<?php echo e($tarea->categoria->color); ?>"><?php echo e($tarea->categoria->nombre); ?></span>  <a href="#" title="Eliminar tarea" class="btn btn-circulo btn-danger">X</a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>